package org.debreloza.messenger

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        val bar = LinearLayout(this).apply {
            setPadding(22, 24, 16, 18)
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.rgb(34,158,217))
        }
        val title = TextView(this).apply {
            text = "ደብረ ሎዛ"
            textSize = 23f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        bar.addView(title, LinearLayout.LayoutParams(0, -2, 1f))

        val search = Button(this).apply {
            text = "🔎"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { Toast.makeText(this@MainActivity, "ፍለጋ", Toast.LENGTH_SHORT).show() }
        }
        bar.addView(search, LinearLayout.LayoutParams(55, 55))
        root.addView(bar)

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 8)
        }
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
        }

        root.addView(tabs, LinearLayout.LayoutParams(-1, -2))
        root.addView(ScrollView(this).apply { addView(list) },
            LinearLayout.LayoutParams(-1, 0, 1f))

        addTab(tabs, "Chats") { chats() }
        addTab(tabs, "Groups") { groups() }
        addTab(tabs, "Classes") { classes() }
        addTab(tabs, "Library") { library() }

        chats()
        setContentView(root)
    }

    private fun addTab(parent: LinearLayout, text: String, action: () -> Unit) {
        parent.addView(Button(this).apply {
            this.text = text
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun clear() { list.removeAllViews() }

    private fun item(title: String, subtitle: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = "$title\n$subtitle"
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            textSize = 16f
            setPadding(20, 22, 20, 22)
            setOnClickListener { action() }
        }
        list.addView(b, LinearLayout.LayoutParams(-1, -2))
    }

    private fun chats() {
        clear()
        item("⛪ የጫጫ ደብረ ሎዛ ሰንበት ት/ቤት", "የት/ቤቱ ዋና ውይይት") { chat("ዋና ውይይት") }
        item("📢 ማስታወቂያ", "አዲስ የት/ቤት መረጃ") { chat("ማስታወቂያ") }
        item("📖 የዕለቱ ትምህርት", "መንፈሳዊ ትምህርት") { chat("የዕለቱ ትምህርት") }
    }

    private fun groups() {
        clear()
        item("👥 የክፍል ቡድኖች", "Preschool A/B → Grade 12") { classes() }
        item("⛪ የሰንበት ት/ቤት ቡድን", "የት/ቤቱ አባላት") { chat("የሰንበት ት/ቤት ቡድን") }
    }

    private fun classes() {
        clear()
        val names = listOf("Preschool A","Preschool B") + (1..12).map { "Grade $it" }
        names.forEach { n -> item("📚 $n", "የ$ n ክፍል") { chat(n) } }
    }

    private fun library() {
        clear()
        item("📚 ቤተ-መጻሕፍት", "መጻሕፍትና የትምህርት ማስረጃዎች") {}
        item("📜 ትምህርቶች", "የሰንበት ት/ቤት ትምህርቶች") {}
        item("📢 ማስታወቂያዎች", "የት/ቤቱ ማስታወቂያ") {}
    }

    private fun chat(name: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
        }
        val header = TextView(this).apply {
            text = "‹  $name"
            textSize = 20f
            setPadding(0, 10, 0, 20)
            setOnClickListener { showHome() }
        }
        box.addView(header)
        val messages = TextView(this).apply {
            text = "ወደ $name እንኳን በደህና መጡ።\n\nይህ የደብረ ሎዛ የመልዕክት ክፍል ነው።"
            textSize = 17f
            setPadding(8, 30, 8, 30)
        }
        box.addView(messages, LinearLayout.LayoutParams(-1, 0, 1f))
        val input = EditText(this).apply { hint = "መልዕክት..." }
        val send = Button(this).apply {
            text = "ላክ"
            setOnClickListener {
                if (input.text.isNotBlank()) {
                    messages.append("\n\nአንተ: ${input.text}")
                    input.text.clear()
                }
            }
        }
        box.addView(input)
        box.addView(send)
        setContentView(box)
    }
}